
===============
Frozen v1.1.0.2
===============

This is the first release of Frozen for Windows in 2014. It contains:

- frozen-qt.exe - The GUI version of Frozen - this is the standard wallet for Windows
- frozend.exe   - The frozen daemon. Use it if you want to run Frozen without graphical interface
- md5sum.txt    - The MD5-sum of each of the binaries above
- readme.txt    - This text


LOCATION OF frozen.conf

The location of a custom frozen.conf depends on your version of Windows:

    Windows 7       C:\Users\<username>\AppData\Roaming\Frozen\frozen.conf                          
    Windows Vista   C:\Users\<username>\AppData\Roaming\Frozen\frozen.conf                          
    Windows XP      C:\Documents and Settings\<username>\Application Data\Frozen\frozen.conf


